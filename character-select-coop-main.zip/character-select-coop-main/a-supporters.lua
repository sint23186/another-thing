CREDIT_SUPPORTERS = {
    "Saul",
    "Ellie",
    "Lyrae",
    "Sophia",
    "maemae",
    "charity",
    "FunkyLion",
}